from flask import Flask, render_template, request, redirect, url_for, flash
from DB_Operations import fetch_all_items, insert_item, fetch_item_by_id, update_item, delete_item

app = Flask(__name__)
app.secret_key = "your_secret_key"

@app.route('/', methods=["POST", "GET"])
def index():
    items = fetch_all_items()  # Fetch all messages from the database
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        pesan = request.form['pesan']
        # Insert item into the database
        insert_item(name, email, pesan)
        flash('Item Added Successfully!')
        return redirect(url_for('index'))
    return render_template('index.html', items=items)

@app.route('/edit/<id>', methods=["GET", "POST"])
def edit_item(id):
    item = fetch_item_by_id(id)
    if not item:
        flash("Item not found!")
        return redirect(url_for('index'))
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        pesan = request.form['pesan']
        # Update item
        update_item(id, name, email, pesan)
        flash('Item Updated Successfully!')
        return redirect(url_for('index'))
    return render_template('edit.html', item=item)

@app.route('/delete/<id>', methods=["POST"])
def delete_item_route(id):
    delete_item(id)
    flash('Item Deleted Successfully!')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
