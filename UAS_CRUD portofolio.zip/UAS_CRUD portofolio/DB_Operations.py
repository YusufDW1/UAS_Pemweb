import pymysql

def connect():
    return pymysql.connect(host="localhost",
                            user="root",
                            passwd="",
                            database="contact",  # Change this to your database name
                            cursorclass=pymysql.cursors.DictCursor)

def fetch_all_items():
    connection = connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM form")  # Assuming the table name is 'form'
            rows = cursor.fetchall()
        return rows
    finally:
        connection.close()

def insert_item(name, email, pesan):
    connection = connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute("INSERT INTO form (name, email, pesan) VALUES (%s, %s, %s)",
                           (name, email, pesan))
            connection.commit()
        return 1
    finally:
        connection.close()

def fetch_item_by_id(item_id):
    connection = connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM form WHERE id = %s", (item_id,))
            row = cursor.fetchone()
        return row
    finally:
        connection.close()

def update_item(item_id, name, email, pesan):
    connection = connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute("UPDATE form SET name = %s, email = %s, pesan = %s WHERE id = %s",
                           (name, email, pesan, item_id))
            connection.commit()
        return 1
    finally:
        connection.close()

def delete_item(item_id):
    connection = connect()
    try:
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM form WHERE id = %s", (item_id,))
            connection.commit()
        return 1
    finally:
        connection.close()
